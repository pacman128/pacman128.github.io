#ifndef CDECL_HEADER_FILE
#define CDECL_HEADER_FILE

#if defined(__GNUC__)
#  define PRE_CDECL
#  define POST_CDECL __attribute__((cdecl))
#else
#  define PRE_CDECL __cdecl
#  define POST_CDECL
#endif


#endif
